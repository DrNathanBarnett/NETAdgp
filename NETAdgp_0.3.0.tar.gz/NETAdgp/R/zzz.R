.onLoad <- function(libname, pkgname) {
  required_packages <- c("dplyr", "clustermole", "Seurat", "STRINGdb", "tidyr", 
                        "limma", "gprofiler2", 
                         "edgeR")
  for (pkg in required_packages) {
    if (!requireNamespace(pkg, quietly = TRUE)) {
      message(paste("Installing missing package:", pkg))
      install.packages(pkg)
    }
  }
}
